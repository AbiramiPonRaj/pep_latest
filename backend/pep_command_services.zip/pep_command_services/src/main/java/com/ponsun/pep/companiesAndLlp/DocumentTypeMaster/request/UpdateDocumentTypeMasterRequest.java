package com.ponsun.pep.companiesAndLlp.DocumentTypeMaster.request;

public class UpdateDocumentTypeMasterRequest extends AbstractDocumentTypeMasterRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
