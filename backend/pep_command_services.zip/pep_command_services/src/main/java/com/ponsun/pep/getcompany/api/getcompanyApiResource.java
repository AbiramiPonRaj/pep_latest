package com.ponsun.pep.getcompany.api;



import com.ponsun.pep.getcompany.data.getcompanyData;
import com.ponsun.pep.getcompany.services.FileDownloadUtils;
import com.ponsun.pep.getcompany.services.getcompanyReadPlatformService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/v1/Getcompany")
public class getcompanyApiResource {

    private final getcompanyReadPlatformService getcompanyReadPlatformService;
    private final FileDownloadUtils fileDownloadUtils;

    @GetMapping("/file")
    public List<getcompanyData> getCompanyFile(@RequestParam("din") String din){
        return this.getcompanyReadPlatformService.getCompanyFile(din);
    }

    @GetMapping("/fileemtycompany")
    public List<getcompanyData> getemtyCompany(@RequestParam("din") String din){
        return this.getcompanyReadPlatformService.getemtyCompany(din);
    }

    @GetMapping
    public List<getcompanyData> fetchAll(@RequestParam("companyId") Integer companyId,
                                         @RequestParam("pathId") Integer pathId) {
        return this.getcompanyReadPlatformService.getDocumentType(companyId, pathId);
    }

    @GetMapping("/download")
    public ResponseEntity<?> downloadCompanyFile(@RequestParam("companyId") Integer companyId,
                                                 @RequestParam("pathId") Integer pathId) {
        List<getcompanyData> documentTypes = fetchAll(companyId, pathId);

        if (documentTypes.isEmpty()) {
            return new ResponseEntity<>("No documents found for the given companyId and pathId", HttpStatus.NOT_FOUND);
        }

        String imageName = documentTypes.get(0).getDocumentType();

        try {
            Resource resource = fileDownloadUtils.getCompanyFileAsResource(companyId, imageName, pathId);
            if (resource == null) {
                return new ResponseEntity<>("File not found", HttpStatus.NOT_FOUND);
            }

            String contentType = fileDownloadUtils.getContentType();
            if (contentType == null) {
                contentType = "application/octet-stream";
            }

            String headerValue = "attachment; filename=\"" + resource.getFilename() + "\"";

            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION, headerValue)
                    .body(resource);

        } catch (IOException e) {
            return new ResponseEntity<>("Error occurred while retrieving the file", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

//
//@RestController
//@RequiredArgsConstructor
//@CrossOrigin(origins = "http://localhost:3000")
//@RequestMapping("/api/v1/GetDocumentType")
//public class GetDocumentTypeApiResource {
//
//    private  final GetDocumentTypeReadPlatformService getDocumentTypeReadPlatformService;
//
//
//        private final FileDownloadUtils fileDownloadUtils;
//
//    @GetMapping
//    public List<GetDocumentTypeData> getCompanyFile(@RequestParam("companyId") Integer companyId,
//                                              @RequestParam("pathId") Integer pathId) {
//        return this.getDocumentTypeReadPlatformService.getDocumentType(companyId, pathId);
//    }
//
//
//        @GetMapping
//        public List<GetDocumentTypeData> fetchAll(@RequestParam("companyId") Integer companyId,
//                                                  @RequestParam("pathId") Integer pathId) {
//            return this.getDocumentTypeReadPlatformService.getDocumentType(companyId, pathId);
//        }
//
//        @GetMapping("/download")
//        public ResponseEntity<?> downloadCompanyFile(@RequestParam("companyId") Integer companyId,
//                                                     @RequestParam("pathId") Integer pathId) {
//
//            List<GetDocumentTypeData> documentTypes = fetchAll(companyId, pathId);
//
//            if (documentTypes.isEmpty()) {
//                return new ResponseEntity<>("No documents found for the given companyId and pathId", HttpStatus.NOT_FOUND);
//            }
//
//            String imageName = documentTypes.get(0).getDocumentType();
//
//            try {
//                Resource resource = fileDownloadUtils.getCompanyFileAsResource(companyId, imageName, pathId);
//                if (resource == null) {
//                    return new ResponseEntity<>("File not found", HttpStatus.NOT_FOUND);
//                }
//
//                String contentType = fileDownloadUtils.getContentType();
//                if (contentType == null) {
//                    contentType = "application/octet-stream";
//                }
//
//                String headerValue = "attachment; filename=\"" + resource.getFilename() + "\"";
//
//                return ResponseEntity.ok()
//                        .contentType(MediaType.parseMediaType(contentType))
//                        .header(HttpHeaders.CONTENT_DISPOSITION, headerValue)
//                        .body(resource);
//
//            } catch (IOException e) {
//                return new ResponseEntity<>("Error occurred while retrieving the file", HttpStatus.INTERNAL_SERVER_ERROR);
//            }
//        }
//
//}