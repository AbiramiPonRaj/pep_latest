package com.ponsun.pep.getcompany.services;

import com.ponsun.pep.getcompany.data.getcompanyData;
import com.ponsun.pep.getcompany.rowmapper.getcompanyRowMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class getcompanyReadPlatformServiceImpl implements getcompanyReadPlatformService {

    private final JdbcTemplate jdbcTemplate;
    private final getcompanyRowMapper getcompanyRowMapper;

    @Override
    public List<getcompanyData> getDocumentType(Integer companyId, Integer pathId) {
        final getcompanyRowMapper rowMapper = new getcompanyRowMapper();

        String Qry = "SELECT  companyId,pathId,CONCAT(id) AS documentType,CONCAT(url, '\\\\',id, '.', documentType) AS concatenated FROM pep_document_companies" ;
        String whereClause = " WHERE companyId = ? AND pathId = ? AND STATUS='A'";
        Qry = Qry + whereClause;
        final List<getcompanyData> getDocumentTypeDataList = jdbcTemplate.query(Qry,getcompanyRowMapper,
                new Object[] {companyId,pathId}
        );
        return getDocumentTypeDataList;
    }

    @Override
    public List<getcompanyData> getCompanyFile(String din) {
        try {
            String query = "SELECT b.id AS companyId,c.`id`,b.`companyName`,a.id AS documentId,a.`companyId`,a.`pathId`,a.`documentType`,a.`url`,CONCAT(a.url, '\\\\',a.id, '.', a.`documentType`) AS concatenated " +
                    "FROM `pep_document_companies` a,`pep_associated_companies` b,pep_config_companies_directors c,pep_customer d,pep_companies_directors e " +
                    " WHERE d.directorsIdentificationNumber=c.din AND c.id=e.directorId AND b.id=e.companyId AND a.companyId=e.companyId AND " +
                    "   d.directorsIdentificationNumber= ? AND a.status = 'A' AND b.status = 'A' AND e.status = 'A'  GROUP BY b.id;";

            return jdbcTemplate.query(query, new Object[]{din}, (rs, rowNum) -> {
                getcompanyData data = new getcompanyData();

                data.setId(rs.getInt("documentId"));
//                data.setDocumentId(rs.getInt("documentId"));
                data.setUrl(rs.getString("url"));
                data.setDocumentType(rs.getString("documentType"));
                data.setCompanyName(rs.getString("companyName"));
                data.setCompanyId(rs.getInt("companyId"));
                data.setPathId(rs.getInt("pathId"));
                data.setConcatenated(rs.getString("concatenated"));
                return data;
            });
        } catch (DataAccessException e) {
            throw new RuntimeException(e);
        }
    }



    @Override
    public List<getcompanyData> getemtyCompany(String din) {
        try {
            String query =  "SELECT companyId, directorId, companyName, documentId " +
            " FROM (SELECT b.id AS companyId, c.id AS directorId, b.companyName, a.id AS documentId, a.companyId AS documentCompanyId, a.pathId, a.documentType, a.url, a.status AS documentStatus " +
            " FROM pep_associated_companies b " +
            " LEFT JOIN pep_companies_directors e ON b.id = e.companyId " +
            " LEFT JOIN pep_config_companies_directors c ON c.id = e.directorId " +
            " LEFT JOIN pep_customer d ON d.directorsIdentificationNumber = c.din " +
            " LEFT JOIN pep_document_companies a ON a.companyId = e.companyId " +
            " WHERE d.directorsIdentificationNumber = ? AND b.status = 'A' AND e.status = 'A' GROUP BY b.id) a WHERE documentId IS NULL OR documentStatus = 'D'";

            System.out.println("query"+query);
            return jdbcTemplate.query(query, new Object[]{din}, (rs, rowNum) -> {
                getcompanyData data = new getcompanyData();

                data.setId(rs.getInt("documentId"));
//                data.setDocumentType(rs.getString("documentType"));
                data.setCompanyName(rs.getString("companyName"));
                data.setCompanyId(rs.getInt("companyId"));
                data.setPathId(rs.getInt("pathId"));
                return data;
            });
        } catch (DataAccessException e) {
            throw new RuntimeException(e);
        }
    }


}