package com.ponsun.pep.getcompanyemty.rowmapper;

import com.ponsun.pep.getcompanyemty.data.GetcompanyemtyData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;

@Data
@Service
@Slf4j
public class GetcompanyemtyRowMapper implements RowMapper<GetcompanyemtyData> {

    private final String schema;
    public GetcompanyemtyRowMapper(){
        final StringBuilder builder = new StringBuilder(200);
        builder.append(" FROM pep_document_companies");
        this.schema = builder.toString();
    }

    @Override
    public GetcompanyemtyData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer documentId = rs.getInt("documentId");
        final Integer directorId = rs.getInt("directorId");
        final Integer companyId = rs.getInt("companyId");
        final String companyName = rs.getString("companyName");
        return GetcompanyemtyData.newInstance(documentId, companyId,directorId,  companyName);
    }

}
