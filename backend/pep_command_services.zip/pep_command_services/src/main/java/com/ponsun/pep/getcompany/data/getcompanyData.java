package com.ponsun.pep.getcompany.data;

import lombok.Data;

@Data
public class getcompanyData {
    private Integer id;
    private Integer companyId;
//    private Integer documentId;
    private Integer pathId;
    private String documentType;
    private String concatenated;
    private String companyName;
    private String url;

    public getcompanyData() {
    }

    public getcompanyData(final Integer id, final Integer companyId , final Integer pathId , final String url, final String companyName, final String documentType, final String concatenated){
        this.id = id;
        this.companyId = companyId;
//        this.documentId= documentId;
        this.pathId = pathId;
        this.documentType = documentType;
        this.concatenated = concatenated;
        this.url =url;
        this.companyName=companyName;
    }
    public static getcompanyData newInstance (final Integer id, final Integer companyId , final Integer pathId , final String url, final String companyName, final String documentType, final String concatenated){
        return new getcompanyData(id,companyId ,pathId ,url,companyName, documentType ,concatenated);
    }
}
