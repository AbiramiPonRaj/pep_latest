package com.ponsun.pep.companiesAndLlp.CompaniesDirectors.request;
import lombok.Data;

@Data
public class CreatCompaniesDirectorsRequest extends AbstractCompaniesDirectorsRequest {
    @Override
    public String toString(){ return super.toString();}

}
