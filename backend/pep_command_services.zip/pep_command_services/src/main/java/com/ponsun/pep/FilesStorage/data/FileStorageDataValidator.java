package com.ponsun.pep.FilesStorage.data;

public class FileStorageDataValidator {
}
