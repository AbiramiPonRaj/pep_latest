package com.ponsun.pep.adminconfiguration.adminconfigmoduledet.request;

import lombok.Data;

@Data
public class UpdateAdminConfigModuleDetRequest extends  AbstractAdminConfigModuleDetBaseRequest{
    @Override

    public String toString() { return super.toString();}
}
