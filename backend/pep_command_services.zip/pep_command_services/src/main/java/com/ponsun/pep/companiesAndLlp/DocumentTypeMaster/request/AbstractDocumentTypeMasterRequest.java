package com.ponsun.pep.companiesAndLlp.DocumentTypeMaster.request;

import lombok.Data;

@Data
public class AbstractDocumentTypeMasterRequest {

    private String name;
    private Integer uid;
    private Integer euid;

}
