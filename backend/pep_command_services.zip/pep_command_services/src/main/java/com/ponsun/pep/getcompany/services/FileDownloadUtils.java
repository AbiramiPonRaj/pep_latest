package com.ponsun.pep.getcompany.services;

import org.apache.commons.io.FilenameUtils;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;


@SpringBootApplication
public class FileDownloadUtils {

    private Path foundFile;
    private final String baseRoot = "D:\\uploadImages";

    public Resource getCompanyFileAsResource(Integer companyId, String imageName, Integer pathId) throws IOException {
        String resolvedRootDirectory = "";

        if (pathId == 5) {
            resolvedRootDirectory = "about_companyDetails\\" + companyId;
        } else if (pathId == 6) {
            resolvedRootDirectory = "DirectorsList\\" + companyId;
        }

        Path root = Paths.get(baseRoot, resolvedRootDirectory);

        Optional<Path> file = Files.list(root)
                .filter(f -> FilenameUtils.removeExtension(f.getFileName().toString()).equals(imageName))
                .findFirst();

        if (file.isPresent()) {
            foundFile = file.get();
            return new UrlResource(foundFile.toUri());
        }

        return null;
    }

    public String getContentType() {
        if (foundFile != null) {
            try {
                return Files.probeContentType(foundFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
