package com.ponsun.pep.companiesAndLlp.CompanyDocuments.request;

public class UpdateCompanyDocumentsRequest extends AbstractCompanyDocumentsRequest {
    @Override
    public String toString() {
        return super.toString();
    }

}