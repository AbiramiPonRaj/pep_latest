package com.ponsun.pep.getcompany.rowmapper;

import com.ponsun.pep.getcompany.data.getcompanyData;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;

@Data
@Service
@Slf4j
public class getcompanyRowMapper implements RowMapper<getcompanyData> {

    private final String schema;
    public getcompanyRowMapper(){
        final StringBuilder builder = new StringBuilder(200);
        builder.append(" FROM pep_document_companies");
        this.schema = builder.toString();
    }
//    public String schema() {
//        return this.schema;
//    }
//    public String tableSchema(){
//        final StringBuilder builder = new StringBuilder(200);
//        builder.append(" companyId,pathId,CONCAT(id) AS documentType,CONCAT(url, '\\\\',id, '.', documentType) AS concatenated");
//        builder.append(this.schema);
//        return builder.toString();
//    }

    @Override
    public getcompanyData mapRow(ResultSet rs, int rowNum) throws SQLException {
        final Integer id = rs.getInt("id");
        final Integer companyId = rs.getInt("companyId");
        final Integer pathId = rs.getInt("pathId");
//        final Integer documentId = rs.getInt("documentId");
        final String url = rs.getString("url");
        final String companyName = rs.getString("companyName");
        final String documentType = rs.getString("documentType");
        final String concatenated = rs.getString("concatenated");
        return getcompanyData.newInstance(id, companyId, pathId, documentType, concatenated, companyName, url);
    }


//    @Override
//    public GetDocumentTypeData mapRow(ResultSet rs, int rowNum) throws SQLException {
//        final Integer id = rs.getInt("id");
//        final Integer companyId = rs.getInt("companyId");
////        final Integer documentId = rs.getInt("documentId");
//        final Integer pathId = rs.getInt("pathId");
//        final String url = rs.getString("url");
//        final String companyName = rs.getString("companyName");
//        final String documentType = rs.getString("documentType");
//        final String concatenated = rs.getString("concatenated");
//        return GetDocumentTypeData.newInstance(id,companyId,pathId,documentType,concatenated,companyName,url);
//    }
}
