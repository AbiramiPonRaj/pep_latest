package com.ponsun.pep.getcompanyemty.services;

import com.ponsun.pep.getcompanyemty.data.GetcompanyemtyData;
import com.ponsun.pep.getcompanyemty.rowmapper.GetcompanyemtyRowMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class GetcompanyemtyReadPlatformServiceImpl implements GetcompanyemtyReadPlatformService {

    private final JdbcTemplate jdbcTemplate;
    private final GetcompanyemtyRowMapper GetcompanyemtyRowMapper;

//    @Override
//    public List<GetcompanyemtyData> getemtyCompany(String din) {
//        try {
//            String query = "  SELECT companyId, directorId, companyName, documentId "+
//                            " FROM ( SELECT b.id AS companyId, c.id AS directorId, b.companyName, a.id AS documentId, a.companyId AS documentCompanyId, a.pathId, a.documentType, a.url, a.status AS documentStatus "+
//                            "     FROM pep_associated_companies b "+
//                            "     LEFT JOIN pep_companies_directors e ON b.id = e.companyId "+
//                            "     LEFT JOIN pep_config_companies_directors c ON c.id = e.directorId "+
//                            "     LEFT JOIN pep_customer d ON d.directorsIdentificationNumber = c.din "+
//                            "     LEFT JOIN pep_document_companies a ON a.companyId = e.companyId "+
//                            " WHERE d.directorsIdentificationNumber = ? AND b.status = 'A' AND e.status = 'A' AND NOT "+
//                            " EXISTS (SELECT 1 FROM pep_document_companies a2 WHERE a2.companyId = a.companyId AND a2.status = 'A') GROUP BY b.id) a "+
//                            " WHERE documentId IS NULL OR documentStatus = 'D'";
//
//            return jdbcTemplate.query(query, new Object[]{din}, (rs, rowNum) -> {
//                GetcompanyemtyData data = new GetcompanyemtyData();
//
//                data.setDocumentId(rs.getInt("documentId"));
//                data.setCompanyName(rs.getString("companyName"));
//                data.setCompanyId(rs.getInt("companyId"));
//                data.setDirectorId(rs.getInt("directorId"));
//                return data;
//            });
//        } catch (DataAccessException e) {
//            throw new RuntimeException(e);
//        }
//    }

    @Override
    public List<GetcompanyemtyData> getemtyCompany(String din) {
        try {
            String query = "SELECT companyId, directorId, companyName, documentId FROM (SELECT b.id AS companyId, c.id AS directorId, b.companyName, a.id AS documentId, a.companyId AS documentCompanyId, a.pathId, a.documentType, a.url " +
                    " FROM pep_associated_companies b " +
                    " LEFT JOIN pep_companies_directors e ON b.id = e.companyId " +
                    " LEFT JOIN pep_config_companies_directors c ON c.id = e.directorId " +
                    " LEFT JOIN pep_customer d ON d.directorsIdentificationNumber = c.din " +
                    " LEFT JOIN pep_document_companies a ON a.companyId = e.companyId AND a.status='A' " +
                    " WHERE d.directorsIdentificationNumber = ? AND b.status = 'A' AND e.status = 'A' GROUP BY b.id) a WHERE documentId IS NULL ";

            return jdbcTemplate.query(query, new Object[]{din}, (rs, rowNum) -> {
                GetcompanyemtyData data = new GetcompanyemtyData();

                data.setDocumentId(rs.getInt("documentId"));
                data.setCompanyName(rs.getString("companyName"));
                data.setCompanyId(rs.getInt("companyId"));
                data.setDirectorId(rs.getInt("directorId"));
                return data;
            });
        } catch (DataAccessException e) {
            throw new RuntimeException(e);
        }
    }
}