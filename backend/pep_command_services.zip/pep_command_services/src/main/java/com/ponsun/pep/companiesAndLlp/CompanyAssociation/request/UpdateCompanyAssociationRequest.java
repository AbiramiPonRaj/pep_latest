package com.ponsun.pep.companiesAndLlp.CompanyAssociation.request;

public class UpdateCompanyAssociationRequest extends AbstractCompanyAssociationRequest {
    @Override
    public String toString(){ return super.toString();}
}
