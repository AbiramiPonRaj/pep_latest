package com.ponsun.pep.getcompanyemty.data;

import lombok.Data;

@Data
public class GetcompanyemtyData {
    private Integer directorId;//
    private Integer companyId;//
    private Integer documentId;
    private String companyName;//
//    private String url;

    public GetcompanyemtyData() {
    }

    public GetcompanyemtyData(final Integer directorId, final Integer companyId , final Integer documentId , final String companyName){
        this.directorId = directorId;
        this.companyId = companyId;
        this.documentId= documentId;
        this.companyName=companyName;
    }
    public static GetcompanyemtyData newInstance (final Integer directorId, final Integer companyId , final Integer documentId, final String companyName){
        return new GetcompanyemtyData(directorId,companyId ,documentId ,companyName);
    }
}
