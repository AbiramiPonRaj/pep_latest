package com.ponsun.pep.getcompany.services;

import com.ponsun.pep.getcompany.data.getcompanyData;

import java.util.List;

public interface getcompanyReadPlatformService {
    List<getcompanyData> getDocumentType(Integer companyId, Integer pathId);

    List<getcompanyData> getCompanyFile(String din);

    List<getcompanyData> getemtyCompany(String din);

}
