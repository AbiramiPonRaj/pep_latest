package com.ponsun.pep.companiesAndLlp.AssociatedCompanies.data;

public class AssociatedCompaniesDataValidator {
}
