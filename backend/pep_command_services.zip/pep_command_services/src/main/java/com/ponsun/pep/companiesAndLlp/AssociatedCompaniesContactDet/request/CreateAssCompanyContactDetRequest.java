package com.ponsun.pep.companiesAndLlp.AssociatedCompaniesContactDet.request;

public class CreateAssCompanyContactDetRequest extends AbstractAssCompanyContactDetRequest {
    @Override
        public String toString() {
    return super.toString();
}
    }
