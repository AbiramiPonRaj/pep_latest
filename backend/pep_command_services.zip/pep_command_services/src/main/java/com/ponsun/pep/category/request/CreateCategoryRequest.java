package com.ponsun.pep.category.request;

public class CreateCategoryRequest extends AbstractCategoryRequest{
    @Override
    public String toString() {
        return super.toString();
    }
}
