package com.ponsun.pep.companiesAndLlp.AssCompaniesAddress.request;

public class UpdateCompaniesAddressRequest extends AbstractCompaniesAddressRequest {
    @Override
    public String toString(){ return super.toString();}
}
