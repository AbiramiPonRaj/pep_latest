package com.ponsun.pep.companiesAndLlp.DirectorsMaster.request;

import lombok.Data;

@Data
public class UpdateDirectorMasterRequest extends AbstractDirectorMasterRequest{

    @Override
    public String toString(){
        return super.toString();
    }
}