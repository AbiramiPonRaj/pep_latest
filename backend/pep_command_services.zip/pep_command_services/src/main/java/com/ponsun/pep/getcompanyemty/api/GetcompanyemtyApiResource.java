package com.ponsun.pep.getcompanyemty.api;


import com.ponsun.pep.getcompanyemty.data.GetcompanyemtyData;
import com.ponsun.pep.getcompanyemty.services.GetcompanyemtyReadPlatformService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/v1/Getcompanyemty")
public class GetcompanyemtyApiResource {

    private final GetcompanyemtyReadPlatformService GetcompanyemtyReadPlatformService;

    @GetMapping("/fileemtycompany")
    public List<GetcompanyemtyData> getemtyCompany(@RequestParam("din") String din) {
        return this.GetcompanyemtyReadPlatformService.getemtyCompany(din);
    }
}

