package com.ponsun.pep.getDirectors.request;

import lombok.Data;

@Data
public class CreateGetDirectorsRequest extends AbstractGetDirectorsRequest {
    @Override
    public String toString(){ return super.toString();}
}
