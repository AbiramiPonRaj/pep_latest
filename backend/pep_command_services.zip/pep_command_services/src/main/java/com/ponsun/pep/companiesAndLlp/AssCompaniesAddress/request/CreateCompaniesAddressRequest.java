package com.ponsun.pep.companiesAndLlp.AssCompaniesAddress.request;

import lombok.Data;

@Data
public class CreateCompaniesAddressRequest extends AbstractCompaniesAddressRequest {
    @Override
    public String toString(){ return super.toString();}
}
