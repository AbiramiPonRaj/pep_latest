package com.ponsun.pep.companiesAndLlp.CompanyMaster.request;

import lombok.Data;

@Data
public class CreateCompanyRequest extends AbstractCompanyRequest{
    @Override
    public String toString() {
        return super.toString();
    }
}
