package com.ponsun.pep.getcompanyemty.services;

import com.ponsun.pep.getcompanyemty.data.GetcompanyemtyData;

import java.util.List;

public interface GetcompanyemtyReadPlatformService {
    List<GetcompanyemtyData> getemtyCompany(String din);
}
