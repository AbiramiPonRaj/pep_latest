package com.ponsun.pep.companiesAndLlp.CompanyMaster.request;

import lombok.Data;

@Data
public class UpdateCompanyRequest extends AbstractCompanyRequest{
    @Override
    public String toString() {
        return super.toString();
    }
}
