package com.ponsun.pep.companiesAndLlp.AssociatedCompanies.request;

public class UpdateAssociatedCompaniesRequest extends AbstractAssociatedCompaniesRequest {
    @Override
    public String toString(){ return super.toString();}
}
